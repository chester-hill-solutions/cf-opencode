import type { FixtureID } from "./fixtures"

export interface CodingTask { id: string; repo: FixtureID; prompt: string; checks: string[] }

export const tasks: CodingTask[] = [
  { id: "L1", repo: "ledger", prompt: "Fix parseLines(text) in src/index.ts to accept a single leading UTF-8 BOM, LF or CRLF, blank/whitespace-only lines and a final line without a newline. Preserve parsed order. Malformed nonblank JSON must throw an Error whose message includes the physical 1-based line number. Do not silently skip malformed records. Keep the existing API and basic tests passing.", checks: ["BOM/CRLF/blank/final-line parsing", "physical malformed-line number"] },
  { id: "L2", repo: "ledger", prompt: "Make parseAmount(value:string) convert a decimal currency string into exact integer cents without floating-point rounding. Allow an optional leading minus, digits, and optionally one or two fractional digits. Reject empty, whitespace, plus signs, exponents, nonfinite values, more than two fractional digits and results outside the safe-integer range. Return positive zero for negative zero. Keep the existing API and basic tests passing.", checks: ["exact signed cents", "syntax and safe-integer boundaries", "no negative zero"] },
  { id: "L3", repo: "ledger", prompt: "Harden summarize(rows) in src/index.ts. Currency labels such as __proto__, constructor and toString must be ordinary independent keys. Reject an empty/non-string currency, non-safe-integer cents or an overflowing total. Preserve the Record<string,number> API, do not mutate inputs and keep basic tests passing.", checks: ["prototype-like keys", "invalid amounts/labels", "overflow and input immutability"] },
  { id: "L4", repo: "ledger", prompt: "Make mergeLedgers(left,right) merge by nonempty string id in first-seen order. Identical duplicates (same id, currency and cents) collapse to one; conflicting duplicates throw before returning a result. Do not mutate or alias input records: editing a returned record must not edit an input record. Keep basic tests passing.", checks: ["order and deduplication", "conflict/invalid id rejection", "no input alias"] },
  { id: "L5", repo: "ledger", prompt: "Fix src/cli.ts so a failed input read, malformed JSON or invalid summary leaves an existing output file byte-for-byte intact. Compute and validate before publishing, then write to a unique temporary sibling and rename it into place. Clean up the temporary file on success or failure. Valid input still writes the summary plus newline. Keep basic tests passing.", checks: ["failed input preserves old output", "success atomically publishes summary", "temporary-file cleanup"] },
  { id: "Q1", repo: "queue", prompt: "Fix WorkQueue so a rejected or synchronously throwing task frees its slot and later tasks keep running. Each returned promise must settle exactly once, active/pending counts must return to zero, and the concurrency bound must still hold. Keep the API and existing tests passing.", checks: ["async reject and sync throw release slot", "later task completion", "zero final counts"] },
  { id: "Q2", repo: "queue", prompt: "Implement run(work,{priority?:number}) scheduling in WorkQueue. Higher priority queued work starts first; equal priorities preserve FIFO order; omitted priority means zero. Never preempt a running task. Keep the API and existing tests passing.", checks: ["descending priority", "stable FIFO ties", "running task not preempted"] },
  { id: "Q3", repo: "queue", prompt: "Implement run(work,{signal?:AbortSignal}) queued cancellation in WorkQueue. Pre-aborted or aborted-while-queued work must reject with name AbortError and never execute; canceling one job must leave others intact. After work starts, aborting its signal must not interrupt it or release its slot early. Remove queued abort listeners when the job starts or is canceled. Keep existing tests passing.", checks: ["pre-abort and queued abort", "other work preserved", "active abort does not free slot"] },
  { id: "Q4", repo: "queue", prompt: "Add setConcurrency(value:number):void to WorkQueue and validate the constructor's concurrency. Accept only integers 1 through 16; reject invalid values without changing the current limit. Increasing the limit starts waiting tasks immediately. Decreasing it leaves running jobs intact and starts no more until active work is below the new limit. Keep existing tests passing.", checks: ["validation and unchanged limit on refusal", "increase drains", "decrease preserves active jobs"] },
  { id: "Q5", repo: "queue", prompt: "Add onIdle():Promise<void> to WorkQueue. It resolves only after both active and pending work are empty, supports multiple waiters, resolves immediately for an idle queue, and works again after another batch is enqueued. Keep existing tests passing.", checks: ["multiple waiters", "pending work included", "repeated batches"] },
]

export const faults = [
  { id: "F1", task: "L5", trigger: "Disconnect the client after durable acceptance, before the first tool result.", success: "Reconnect using the saved operation/event cursor; observe the original operation and oracle result without resubmitting the prompt." },
  { id: "F2", task: "Q1", trigger: "Evict only the coordinator DO after a recorded tool-start boundary; preserve its container.", success: "Recover the same accepted operation and files; count every model/tool restart, repeated effect and intervention." },
  { id: "F3", task: "L5", trigger: "Destroy the disposable container after a verified recovery point and a later recorded edit.", success: "Name the actual restored recovery point and lost bytes; report unsupported recovery or lost edits truthfully, never call restored history task success." },
  { id: "F4", task: "Q2", trigger: "Drop the first prompt-acceptance response after server-side durable acceptance; retry using the same operation identity and payload.", success: "No second accepted operation or duplicate external effect; an ambiguous outcome remains explicit." },
  { id: "F5", task: "L5", trigger: "Fail checkpoint publication after task output exists, before a successful checkpoint receipt.", success: "No false checkpoint success or unsafe deletion; preserve the prior checkpoint and report unsaved work/intervention explicitly." },
] as const

export const protocol = {
  schemaVersion: 1,
  id: "r0-23-v8",
  scope: "Authored diagnostic coding suite, not population-level model accuracy or a completed G0 representative-workload qualification.",
  arms: ["aboiteau", "opencode-harness-linux"],
  strata: {
    product: "Compare complete configurations; pin and disclose system prompts, tools, policies and runtime differences.",
    matched: "Unrated until the same model endpoint/settings, runtime version, tool schemas/behavior, system instructions and permissions are proved equivalent.",
  },
  repetitions: { ordinary: 3, conditions: ["cold", "warm"], faults: 3, modelTurnDeadlineMs: 900_000 },
  order: "Pair by task/condition/repetition; alternate the arm that goes first. Fresh fixture repo per attempt. Warm trials prime only runtime/provider connectivity with no model turn; do not leak prior task solutions.",
  metrics: ["acceptedTask", "oraclePassed", "publicTestsPassed", "wallMs", "firstOutputMs", "restoreMs", "checkpointMs", "modelUSD", "containerUSD", "storageUSD", "operatorSeconds", "interventions", "duplicateEffects", "unknownUsage", "lostFiles"],
  decision: { minAcceptedFraction: 0.9, minRelativeBenefit: 0.2, maxAcceptedFractionRegression: 0.05, maxMedianLatencyRegression: 0.1, maxCostRegression: 0.1, catastrophicViolationsAllowed: 0, p95MinimumSamples: 20,
    rule: "Reuse/reduce is a candidate only with no accounting/security/false-recovery violations, <=5 percentage-point task acceptance regression and >=20% measured cost or intervention reduction, without >10% regression in the other measured cost/latency metric. Missing costs, task equivalence or insufficient samples mean inconclusive; no automatic migration." },
  execution: { phase: "authorized-four-attempt-smoke", model: "opencode/deepseek-v4.1-flash", providerEndpoint: "https://opencode.ai/inference/openai/v1/chat/completions", temperature: 0, maxOutputTokens: 4096, stagingAccount: "ad5ec479b9a421faa2ed06c3d1c2b23a", spendBudgetUSD: 5, deploymentNames: ["aboiteau-r0-23-20261115-f1056e"], runEligible: false },
  faults,
  tasks,
} as const
