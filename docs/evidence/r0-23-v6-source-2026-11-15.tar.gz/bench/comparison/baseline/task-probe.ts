import { DurableObject } from "cloudflare:workers"
import { Lifecycle } from "agents/lifecycle"
import { OpenCodeHarness } from "agents/harness/opencode"
import { OpenCodeWorkerd } from "@opencode/sdk/workerd"
import { SimulatedToolPlane } from "./linux"
import { steps } from "./provider"
import { durableJournal } from "./task-worker"
import { taskPlugin, taskProviderID } from "./task-plugin"
import { taskModel, type ProviderTransport } from "./task-model"
import { TaskRuntime } from "./task-runtime"

/** Real provider parser and task plugin, synthetic HTTP/SSE, simulated tools. */
export class SyntheticTaskProbe extends DurableObject<ComparisonBindings> {
  private readonly journal
  private readonly lifecycle: Lifecycle<ComparisonBindings>
  private readonly harness: OpenCodeHarness
  private readonly runtime: TaskRuntime
  private readonly stop = new AbortController()

  constructor(ctx: DurableObjectState, env: ComparisonBindings) {
    super(ctx, env)
    this.journal = durableJournal(ctx.storage)
    let calls = 0
    const config = { model: "synthetic-chat-model", baseURL: "https://provider.invalid/v1", temperature: 0, maxOutputTokens: 1024, contextTokens: 32768, maxModelCalls: 8, requestTimeoutMs: 5000 }
    const transport: ProviderTransport = async (input, init) => {
      const body = JSON.parse(String(init?.body))
      if (String(input) !== config.baseURL + "/chat/completions" || init?.redirect !== "error" || body.model !== config.model || body.temperature !== 0 || body.max_tokens !== 1024 || new Headers(init.headers).get("authorization") !== "Bearer synthetic-noncredential") throw new Error("synthetic provider request mismatch")
      const step = steps[calls++]
      const delta = step ? { role: "assistant", tool_calls: [{ index: 0, id: "task-tool-" + calls, type: "function", function: { name: step.tool, arguments: JSON.stringify(step.input) } }] } : { role: "assistant", content: "R0_23_TASK_ADAPTER_COMPLETE" }
      const chunk = (choices: unknown[], usage?: unknown) => "data: " + JSON.stringify({ id: "chat-" + calls, object: "chat.completion.chunk", created: 0, model: config.model, choices, ...(usage ? { usage } : {}) }) + "\n\n"
      return new Response(chunk([{ index: 0, delta, finish_reason: null }]) + chunk([{ index: 0, delta: {}, finish_reason: step ? "tool_calls" : "stop" }]) + chunk([], { prompt_tokens: 10, completion_tokens: 1, total_tokens: 11 }) + "data: [DONE]\n\n", { headers: { "content-type": "text/event-stream" } })
    }
    const model = taskModel(config, "synthetic-noncredential", this.journal, async () => {}, transport, this.stop.signal)
    this.harness = new OpenCodeHarness({ opencode: ({ storage }) => OpenCodeWorkerd.create({ storage, models: { fetch: false },
      config: { default_agent: "build", experimental: { background_compaction: false }, agents: { title: { disabled: true } } },
      plugins: [taskPlugin(new SimulatedToolPlane(), model, this.journal, { context: 32768, output: 1024 })] }),
      defaults: { model: { providerID: taskProviderID, id: config.model }, agent: "build" } })
    this.lifecycle = Lifecycle.install(this).use(this.harness)
    this.runtime = new TaskRuntime(this.journal, () => this.lifecycle.start(), this.harness, this.stop, work => ctx.waitUntil(work), () => this.lifecycle.disableAlarms())
  }

  async fetch(request: Request): Promise<Response> {
    const path = new URL(request.url).pathname
    if (path === "/receipt") return Response.json({ cached: true, receipt: await this.ctx.storage.get("task-probe-receipt") ?? null })
    if (path === "/cleanup") {
      if (!await this.journal.store.read()) return new Response("not found", { status: 404 })
      const result = await this.runtime.cleanup({ async destroy() {}, running: () => false })
      return Response.json({ ...result, alarmsDisabled: result.coordinatorDisposed && await this.ctx.storage.getAlarm() === null }, { status: result.runtimeStopped && result.cleanupRecorded ? 200 : 503 })
    }
    const accepted = await this.journal.admit({ id: "synthetic-task-wiring", taskID: "PROBE", condition: "cold", repetition: 1, protocolSHA256: "synthetic-only", configSHA256: "synthetic-only" })
    if (!accepted) return Response.json({ error: "synthetic task probe already attempted" }, { status: 409 })
    try {
      await this.journal.transition("preparing", "ready"); await this.journal.transition("ready", "running")
      await this.runtime.submit("Exercise the scripted tools.", "synthetic-task-wiring")
      await this.runtime.wait("synthetic-task-wiring", 60_000)
      const receipt = await this.journal.store.read()
      const passed = receipt?.phase === "done" && receipt.result?.text.includes("R0_23_TASK_ADAPTER_COMPLETE") && receipt.tools.length === 5 && receipt.tools.every(tool => tool.status === "done") && receipt.modelCalls.length === 6 && receipt.modelCalls.every(call => call.finished && call.inputTokens === 10 && call.outputTokens === 1)
      const observation = { kind: "synthetic-task-adapter", passed: Boolean(passed), externalProviderCalls: 0, transport: "mocked-http-sse", toolPlane: "simulated", receipt }
      await this.ctx.storage.put("task-probe-receipt", observation)
      return Response.json(observation, { status: passed ? 200 : 422 })
    } catch {
      await this.journal.fail("synthetic task adapter failed")
      const observation = { passed: false, receipt: await this.journal.store.read(), externalProviderCalls: 0 }
      await this.ctx.storage.put("task-probe-receipt", observation)
      return Response.json(observation, { status: 422 })
    }
  }
}
