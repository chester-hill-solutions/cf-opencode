# @chester-hill-solutions/dev-guards

Node/Bun tooling primitives extracted from the Callcaster and GoCanvass guard scripts.
Applications keep their own rules, scan roots, required annotations, baseline identities,
CI scope maps and exit policy. This package has no external runtime dependencies.

## Identity ratchets

`diffRatchet(current, baseline)` returns sorted `fresh` and `stale` identities. A baseline
is a string array or an object whose **keys** are identities; object values are metadata.
These are not per-rule numeric counts. This repository's `scripts/lib/ratchet.mjs` owns
its separate count-based gate, reporting and update policy; it is not replaced by this API.

```ts
import { diffRatchet, loadBaseline, writeBaseline } from "@chester-hill-solutions/dev-guards";

const baseline = loadBaseline("guard-baseline.json"); // missing, unreadable or malformed throws
const { fresh, stale } = diffRatchet(currentIdentities, baseline);
if (fresh.length) throw new Error("New guard violations");
if (updateRequested) writeBaseline("guard-baseline.json", currentIdentities);
else if (stale.length) throw new Error("Record the improvement in the baseline");
```

`writeBaseline` sorts and deduplicates identities. It refuses to add an identity to an
existing baseline, even if another identity was removed. A missing baseline requires an
explicit, reviewed `writeBaseline(path, entries, { establish: true })`. Establishment does
not bypass the no-growth check for an existing file. Writes are synchronous; callers must
serialize writers. This is a development gate, not a concurrent transactional store.

`priorBaselineCount(repoRelativePath, cwd?)` reads `HEAD^` using git without a shell and
returns `null` for missing history, missing files, malformed baselines or git failures.
`baselineGrew(currentCount, priorCount)` **throws** when that prior is unknown or either
count is invalid; unknown history cannot become a passing comparison. CI must fetch the
required parent commit. Count comparison cannot detect identity substitutions: also use
`diffRatchet`. `git(args, cwd?)` captures stdout or returns `null` on failure; callers must
handle `null` as an error or run all relevant checks, never as an empty clean diff.

## Annotation and file scanning

- `walk(root, { skipDirNames, skipFile, include })` lists regular files in deterministic
  name order. Missing, unreadable, non-directory or symlink roots throw. Hidden entries
  and symlinks below the root are skipped, so cycles and links outside the tree are not
  followed. `skipDirNames` applies only to directory names, `include` receives a basename,
  and `skipFile` receives a path relative to the process working directory. Errors during
  traversal propagate. This is tooling for a stable checkout, not a hostile-filesystem
  sandbox; it does not prevent concurrent filesystem replacement.
- `precedingBlock(source, offset, { allowLineComments? })` returns the interior of the
  nearest adjacent JSDoc block, or `""`. Offsets are UTF-16 character positions. Blank
  lines and full-line `//` comments are allowed by default; set `allowLineComments: false`
  for strict blank-line adjacency. Code or another completed block breaks adjacency.
  It scans lines without the catastrophic-backtracking whitespace/comment regexp.
- `parseTags(block, prefixes = ["@note"])` extracts `@tag` and `@tag-sub` with the rest of
  the line as a value. It returns keys including `@`, accepts empty values and lets the
  last occurrence win. An empty prefix list returns no tags. Callers validate their own
  required tags and values; this is not a TypeScript parser.

The root handler registry consumes `precedingBlock` while keeping its required-tag
whitelist, tag-value parsing and admin-auth law local. `bun run test:scripts` builds this
package first; build it before invoking `node scripts/handler-registry.mjs` directly.

## CI scoping

`globToRegExp(pattern)` supports `**` across directories, `**/` for zero or more directory
levels, and `*` within a directory. All other regexp punctuation, including `?`, is literal;
there are no brace, character-class, negation or platform-separator expansions. Supply git
paths with `/` separators. `compileScopes(scopePatterns)` and `classify(files, compiled)`
return independent scope booleans. Classification does not resolve git history: when a
diff is unavailable, the caller must fail or run every scope. An empty list means a known
empty diff, not a failed diff.

## Git hygiene

`findSecrets(text)` returns `{ pattern, index, match }` hits for selected key formats,
private-key headers, PostgreSQL credentials and Bearer tokens. Results contain credential
text: redact them before logging. This heuristic produces false positives and misses other
secret formats; use a dedicated secret scanner for comprehensive checks.
`SECRET_PATTERNS` exposes the patterns; repeated calls do not inherit their regex state.
`conventionalSubjectOk(subject)` accepts one-line conventional subjects from
`CONVENTIONAL_TYPES` and rejects WIP, fixup, squash and merge scratch subjects.

## Scope and verification

This package does not install hooks, execute CI jobs, choose product rules, enforce a
baseline in git, or guarantee that source annotations reflect runtime authorization.
Filesystem/git helpers require Node or Bun; this package is not a Workers runtime library.
No consumer repositories are migrated by adding it here.

```bash
bun run --cwd packages/dev-guards test
bun run --cwd packages/dev-guards typecheck
bun run --cwd packages/dev-guards build
bun run test:scripts
```

The initial API corrects the original PR proposal: unknown prior baselines and bad scan
roots throw, baseline writes cannot absorb new identities, and only JSDoc blocks qualify.
Consumers of the unmerged proposal must handle those failures and explicitly establish a
new baseline. Publication follows the repository's version and CI release process.
