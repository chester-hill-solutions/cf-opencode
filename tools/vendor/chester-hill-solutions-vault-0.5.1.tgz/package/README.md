# @chester-hill-solutions/vault

Per-workspace encrypted credential storage. Derives a workspace-specific key from a master secret and encrypts values at rest.

## Install

```bash
npm install @chester-hill-solutions/vault
```

## Master key

The master key is the root of trust: it never leaves the process, and every secret is encrypted with a key derived from it. Generate one with:

```bash
openssl rand -hex 32   # 64 hex characters
```

Store it as `VAULT_MASTER_KEY` in your secret manager. The vault rejects a key that is not exactly 64 hex characters, at startup rather than at first write.

## Usage

```typescript
import { Vault, createInMemoryVaultStore } from "@chester-hill-solutions/vault";

const vault = new Vault(createInMemoryVaultStore(), process.env.VAULT_MASTER_KEY!);

await vault.setSecret("ws-1", "resend_api_key", "re_abc123");
const apiKey = await vault.getSecret("ws-1", "resend_api_key");
const keys = await vault.listSecrets("ws-1");
await vault.deleteSecret("ws-1", "resend_api_key");
```

Only ciphertext reaches the store. `listSecrets` returns key names, never values.

### Postgres

```typescript
import { createPostgresVaultStore, vaultSecrets, VAULT_DDL, Vault } from "@chester-hill-solutions/vault";
import { drizzle } from "drizzle-orm/postgres-js";

const db = drizzle(client, { schema: { vaultSecrets } });
const vault = new Vault(createPostgresVaultStore(db), process.env.VAULT_MASTER_KEY!);
```

`VAULT_DDL` is the table DDL, matching the `vaultSecrets` definition. Apply it once per environment.

`createInMemoryVaultStore()` is for tests and local dev.

### Key/value storage and Workers

Use the driver-free entry point for Cloudflare Durable Objects and other key/value
backends. It exports the same vault and encryption API plus the key/value adapter;
it does not import Postgres or Drizzle. Drizzle is only required for the root
entry point's Postgres adapter.

```typescript
import { Vault, createKeyValueVaultStore } from "@chester-hill-solutions/vault/core";

const vault = new Vault(createKeyValueVaultStore(ctx.storage), env.VAULT_MASTER_KEY);
await vault.setSecret("ws-1", "api-key", "credential");
```

The backend implements `VaultKeyValueStorage`: asynchronous `get`, `put`, `delete`,
and prefix-filtered `list` methods. It stores ciphertext with creation/update
metadata. Workspace ids, secret names, and optional namespace prefixes are framed
as JSON tuples, so punctuation in an id cannot cross a namespace boundary.

Pass a distinct second argument to `createKeyValueVaultStore(storage, "service-a")`
when several vaults share a backend. This format is separate from custom adapters;
existing backend data is not migrated implicitly. The adapter follows the
backend's transaction guarantees and does not add cross-operation transactions;
serialize writes or use the backend's transaction facility when callers can race.
Each operation emits a `vault.key_value` span using only the OpenTelemetry API.
No keys, workspace ids, ciphertexts, or credential values are added to the span;
the host owns the tracing provider.

## Rotating the master key

A keyring holds several master keys. New secrets are encrypted with the active key; secrets written under any other key in the keyring stay readable.

```typescript
const vault = new Vault(store, {
  activeKeyId: "k2",
  keys: { k1: previousKeyHex, k2: currentKeyHex },
});

// After rotating, move old secrets onto the active key.
await vault.reencryptWorkspace("ws-1");
```

`reencryptSecret(workspaceId, key)` migrates one secret and returns whether it changed. `reencryptWorkspace` returns how many it migrated.

The ids in a keyring are labels for you, not part of the stored secret: a secret names the key material that wrote it, by fingerprint. Renaming a key id is therefore harmless, and secrets written before the vault had a keyring stay readable as long as the same key material is in the ring.

## API

| Member | Purpose |
|---|---|
| `new Vault(store, masterKeyHex \| keyring)` | Validates the master key at construction |
| `vault.getSecret(workspaceId, key)` | Decrypted value, or `null` |
| `vault.setSecret(workspaceId, key, value)` | Encrypts and stores a value |
| `vault.deleteSecret(workspaceId, key)` | Removes a secret |
| `vault.listSecrets(workspaceId)` | Key names held for a workspace |
| `vault.listSecretMetadata(workspaceId)` | Key names with when each was created and last changed, and no value |
| `vault.reencryptSecret(workspaceId, key)` | Re-encrypts one secret under the active key |
| `vault.reencryptWorkspace(workspaceId)` | Re-encrypts every secret for a workspace |
| `vault.activeKeyId` | Id of the key new secrets use |

`VaultStore` is the persistence interface: it stores ciphertext and never sees a plaintext secret. Implement it for your own storage layer. `SecretReader` is the read-only plaintext interface and `SecretStore` adds writes; `Vault` implements both.

## Security notes

- Each workspace's key is derived with HKDF-SHA256 from the master key, so one workspace's secrets cannot be read with another workspace's key, and changing the master key invalidates everything written under the old one.
- Secrets are sealed with AES-256-GCM under a random 12-byte IV.
- The ciphertext carries the key fingerprint and format version, so a rotation can tell which key wrote a secret.

## Breaking changes in 0.2.0

- **Secrets written before 0.2.0 cannot be read.** The old derivation did not use the master key at all, so every stored value was readable by anyone who knew the algorithm. 0.2.0 fixes that and refuses the old format; re-enter those credentials.
- `vault.get` / `set` / `delete` / `list` are now `getSecret` / `setSecret` / `deleteSecret` / `listSecrets`. The new names differ from `VaultStore`'s so a ciphertext store cannot be passed where plaintext is expected.
- `VaultStore.list` is now `VaultStore.listMetadata`, and returns `{ key, createdAt, updatedAt }` per secret instead of key names.

## Testing

```bash
bun run --cwd packages/vault test
```
