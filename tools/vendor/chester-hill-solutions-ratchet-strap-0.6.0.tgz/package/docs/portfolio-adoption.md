# Portfolio adoption implementation

> Historical design and validation record recovered with this package. Consumer scans and packed-artifact claims below refer to their recorded snapshots; they do not establish a rollout of the current recovery candidate.

## Mission

Ship reviewable RatchetStrap adoption paths for Sparkfunds Helcim, NES CRM and Stow TS lint while reconciling existing CHS policy ownership. Preserve each project's enforcement contract and prove behavior with actual reports.

## Key results

1. Shared ESLint rules have one canonical implementation in `eslint-config`; existing exported RatchetStrap rules remain compatible.
2. Sparkfunds Helcim's zero budgets import without grandfathering measured debt; recognized-checker verification and guarded application work.
3. NES CRM gains a scoped identity-baseline adoption patch that retains existing lint and effect-inventory checks.
4. Stow's TS lint has a tested adapter preserving suppression metadata, stale-count failures and predecessor rules.
5. Package checks and isolated consuming-project validation have recorded results; no publication or production rollout is implied.

## Assumptions

The user's “Do it” authorizes the recommended sequence through concrete local changes and consumer migration patches. The current CHS checkout contains unrelated work and must be preserved. Consumer patches are prepared in isolated temporary checkouts on feature branches; the package is unpublished, so registry installation cannot be claimed. Publication and remote merges are outside this pass. Go, duplication, coverage and other non-lint detectors stay unchanged.

## Locked decisions

| Decision | Choice |
| --- | --- |
| Policy owner | Restore upstream `eslint-config`; expose its pure ratchet rules through a subpath |
| Compatibility | Keep original report/count/suppression semantics; stronger policy changes are explicit |
| Helcim baseline | Materialize fixed seven zero defaults; never seed from measured debt |
| NES | Supplement `eslint app --max-warnings 500`; preserve existing guards |
| Stow | TS lint only; preserve nested execution, strict stale counts and history references |
| Verification | Frozen recognized checker where supported; otherwise an explicit old/new same-report contract comparison |
| Consumer delivery | Isolated feature-branch patches and packed-candidate runs; no unrelated checkout mutations |

## Orchestration pattern

Supervisor with independent implementation lanes followed by integration and review.

```mermaid
flowchart LR
  Contract --> SharedPolicy
  Contract --> Helcim
  Contract --> Stow
  Contract --> NES
  SharedPolicy --> Integration
  Helcim --> Integration
  Stow --> Integration
  NES --> Integration
  Integration --> Review --> ConsumerValidation
```

## Team and subtasks

| ID | Role | Model tier | Goal | Success criterion |
| --- | --- | --- | --- | --- |
| Root | Integrator / generalPurpose | large | P1, P5–P9 | One coherent package and evidence |
| Helcim | Implementer / generalPurpose | large | P2, P10H | Verified zero-budget profile and registry-wired patch |
| Stow | Implementer / generalPurpose | large | P3, P10S | Pure adapter/history contracts and registry-wired patch |
| NES | Consumer implementer / generalPurpose | mid | P4, P10N | Scoped report, proposed patch and retained guard evidence |

## Subtask briefs

- Root owns shared-config reconciliation, central Stow integration, packaging, docs and final evidence. Restore only the upstream package files required for policy ownership; do not merge unrelated main changes.
- Helcim owns the new profile's importer, observation, fixed runner, reference harness, migration integration and focused tests. No consumer edits outside owned scratch space; coordinate shared-file ownership before integration.
- Stow owns new isolated `stow` modules and their tests. Preserve source scanner behavior, suppression metadata, strict stale handling and history rules. Send integration instructions; root owns existing central files.
- NES owns an isolated consumer checkout, one fresh matching lint report and a proposed supplementary identity-gate patch. Keep all original commands and limits. Do not install into or edit the real checkout. Root provides the packed artifact for final validation.

## Individually enumerated backlog

| ID | Work | Agent role (subagent_type) | Model tier | Depends on | Done when |
| --- | --- | --- | --- | --- | --- |
| P1 | Reconcile shared rule ownership | Root (generalPurpose) | large | — | Canonical subpath reused and upstream contracts documented |
| P2 | Add Helcim compatibility | Helcim (generalPurpose) | large | — | Import, observation, verifier, apply and focused regressions pass |
| P3 | Preserve Stow lint contracts | Stow (generalPurpose) | large | — | Adapter/history tests cover original behavior |
| P4 | Prepare NES identity adoption | NES (generalPurpose) | mid | — | Scoped report and reviewable patch exist |
| P5 | Integrate Stow CLI | Root (generalPurpose) | large | P2, P3 | Profile executes in nested package and preserves history/stale policy |
| P6 | Validate package | Root (shell) | mid | P1, P2, P5 | Source/test types, tests and build pass |
| P7 | Run consumer pilots | Root (shell) | large | P4, P6 | Packed artifact runs in isolated Helcim/NES/Stow projects |
| P8 | Review integration | Verifier (generalPurpose) | large | P7 | Contract gaps fixed and focused regressions pass |
| P10H | Wire Helcim package registry | Helcim (generalPurpose) | mid | P7 | Scoped registry, CI auth and patch application checked |
| P10N | Wire NES package registry | NES (generalPurpose) | mid | P7 | Workspace installs retain CI auth and original permissions |
| P10S | Wire Stow package registry | Stow (generalPurpose) | mid | P7 | Nested npm scope and installing CI jobs have package access wiring |
| P9 | Record delivery evidence | Root (generalPurpose) | mid | P8, P10H, P10N, P10S | Patches/artifact and actual limits linked |

P1–P4 are parallel-safe with exclusive file ownership. If a task fails twice, narrow its brief and review the contract before retrying; do not silently weaken compatibility.

## Scope

In: P1–P9, P10H/P10N/P10S and the three named lint adoption paths. Out: publication, remote merges, unrelated project fixes, all-project test frameworks, coverage/Go/DRY adapters, new baseline debt in zero-debt projects. Minimal surface: one canonical rules subpath, two lint compatibility adapters and one generic ESLint consumer pilot.

## Risks and backout

| Risk | Control/backout |
| --- | --- |
| Upstream/local divergence | Restore targeted canonical files; preserve unrelated work |
| Counting or history changes | Same-report old/new checks plus planted regressions |
| Unpublished dependencies | Pack local candidates; produce patches rather than claim registry rollout |
| Consumer breakage | Keep original checkers/baselines and work in isolated branches |

## Rubric and acceptance

Correctness means equal observations and gate outcomes, or an explicitly described supplementary gate. Maintainability means policy configuration remains owned by ESLint-config and detectors remain project-owned. Delivery means inspectable patches and evidence, with unsupported migrations left unsupported.

## Verification

Run package typecheck, `bun test src/`, builds, frozen-checker parity tests and packed Node consumer pilots. Run required root checks and report unrelated existing failures separately. Preserve original source/baseline bytes in migration validation.

## Deliverable

Updated local packages, documentation, packed candidates, and isolated consumer migration patches. No hosted publication or completed production rollout claim.

## Execution gate

Default mode: execute P1–P4, integrate P5, then P6–P9. The user has authorized this work; no additional planning confirmation is needed.

## Progress

- P1–P6 complete: canonical shared policy, Helcim verified migration, Stow lint integration, NES patch and package checks.
- P7 complete: final packed Helcim, NES and Stow pilots pass, including installed-byte checks and real regression cases.
- P8 complete: independent reviews found one nested-runner resolution gap; it was reproduced, fixed and regression-tested. No remaining actionable findings.
- P10H/P10N/P10S complete: scoped registry configuration and CI read authentication are included in all three consumer proposals; local checks and patch application checks pass. Hosted package authorization remains unavailable before publication and Actions access grants.
- P9 complete: packed candidates, patches and [validation evidence](portfolio-validation.md) are collected in the ignored local delivery directory.

## Retrospective

Exact installed-file comparisons exposed Bun reusing a preliminary local tarball despite a version match; distinct candidate filenames and byte checks resolved it. Independent review found Stow's ancestor-tool fallback, which is now covered by a focused regression. Final release review also caught missing registry/CI authentication, so consumer patches include install wiring rather than only gate aliases. Shared policy ownership and project-specific detector behavior remain separate.
