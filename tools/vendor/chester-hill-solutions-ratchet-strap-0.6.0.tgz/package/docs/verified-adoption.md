# Verified adoption milestone

> Historical design and validation record recovered with this package. Consumer scans and packed-artifact claims below refer to their recorded snapshots; they do not establish a rollout of the current recovery candidate.

## Mission

Continue RatchetStrap with executable legacy comparison and an explicit migration-apply command, so adoption can move beyond hand-copying preview output.

## Key results

1. One ESLint report feeds both the recognized original checker and RatchetStrap; observations and gate outcomes are compared.
2. A migration can update supported package-script aliases only after equivalent, passing results, unchanged inputs, and installed-package validation.
3. Failed comparisons, stale inputs, existing target baselines, and unsupported checker code leave project files unchanged.
4. An extracted package completes the adoption workflow under Node in an isolated consuming project.

## Assumptions

The user chose to continue RatchetStrap after reviewing alternatives. This milestone extends the completed 0.2.0 scope. Work stays here and in owned temporary fixtures; publication and edits to real consumer repositories are not part of this implementation.

## Locked decisions

| Decision | Choice |
| --- | --- |
| Public commands | `verify`; `migrate --apply` |
| Existing preview | `migrate` and baseline-only `--write` retain their meaning |
| Execution | Only exact recognized checker snapshots execute, through a Node reference harness |
| Lint reuse | The harness supplies a single report; it does not run a second lint scan |
| Mutation | The original baseline stays intact; create the imported baseline and replace only proposed script aliases |
| Dependency installation | Apply requires the same installed RatchetStrap version; it never installs or publishes packages |
| Verification freshness | Bind checker, baseline, manifest, scanned source bytes, and available Git HEAD |

## Orchestration pattern

Parallel reference-verifier and apply-writer implementations, followed by CLI integration and independent review.

```mermaid
flowchart LR
  Contract --> Verifier
  Contract --> Writer
  Verifier --> CLI
  Writer --> CLI
  CLI --> Review --> Artifact
```

## Team and subtasks

| ID | Role | Model tier | Goal | Success criterion |
| --- | --- | --- | --- | --- |
| V | Implementer / generalPurpose | large | A2 reference verifier | Original gate/measurement comparisons pass fixtures |
| M | Implementer / generalPurpose | large | A3 guarded migration writer | Only equivalent passing plans can apply |
| Root | Integrator / generalPurpose | large | A1, A4–A6 | Documented CLI and packed workflow pass |

## Subtask briefs

- V owns verification/reference modules and tests; reads frozen contracts, copies only recognized checker text into owned scratch directories, and cleans them. No consumer edits.
- M owns apply/transaction modules and tests; reads verification snapshots and preserves original baselines, unrelated scripts, dependency metadata, and existing user changes. No package installation.
- Root owns contracts, CLI wiring, docs, release metadata, and artifact validation. An implementation agent reviews integration after its own task completes.

## Individually enumerated backlog

| ID | Work | Agent role | Model tier | Depends on | Done when |
| --- | --- | --- | --- | --- | --- |
| A1 | Freeze verification contract | Root / generalPurpose | large | — | Public result types and plan exist |
| A2 | Compare original checker | V / generalPurpose | large | A1 | Observations and pass/fail compare on both profiles |
| A3 | Apply verified script migration | M / generalPurpose | large | A1 | Stale/failed plans cannot modify project files |
| A4 | Integrate verification CLI | Root / generalPurpose | large | A2–A3 | Preview, verify, and apply have distinct behavior |
| A5 | Review adoption workflow | Reviewer / generalPurpose | large | A4 | Actionable failures fixed and tested |
| A6 | Validate packed artifact | Root / shell | mid | A5 | Node adoption workflow and package checks pass |

A2/A3 are parallel-safe with exclusive files. After two failed attempts, narrow the brief and review the contract before retrying.

## Scope

In: A1–A6, recognized Callcaster/Quick Canvass lint migrations only. Out: publication, real consumer edits, package installation, arbitrary checker execution, or expanding into effects/coverage/metrics adapters.

## Risks and backout

Reference execution uses immutable, fingerprint-checked snapshots and a controlled lint-report harness. Multi-file application uses cooperative locking, unchanged-input validation, exclusive baseline creation, and restoration on failure. Existing legacy checkers/baselines remain available for backout.

## Rubric and acceptance

| Criterion | Evidence |
| --- | --- |
| One shared scan | Original and new observe identical diagnostics/source snapshot |
| No weaker gate | Counts/identities and passing/failing outcomes compared |
| Reviewable mutation | Preview remains available; apply preserves unrelated fields |
| Portable artifact | Extracted-package Node smoke |

## Verification

Package `typecheck`, `test`, and `build`; focused verifier/writer integration tests; actual project read-only comparison where dependencies permit; packed Node apply smoke; root commands with unrelated dependency failures reported separately.

## Deliverable

RatchetStrap 0.3.0 locally ready for verified adoption, with no publication or real-consumer rollout claim.

## Execution gate

Default mode: execute A1, parallel A2/A3, then A4–A6. The user's continuation authorizes these local, reversible changes.

## Progress

- A1–A4 complete: reference comparison, guarded application, and CLI are implemented.
- A5 complete: three independent review findings were reproduced, corrected, and rechecked; 10 focused regressions pass.
- A6 complete: the packed candidate was installed and adopted in an isolated Quick Canvass checkout; a clean lockfile reinstall and its existing npm gate both pass.

## Current verification evidence

| Check | Result |
| --- | --- |
| Package source/test typecheck | Pass |
| Package tests | 195 pass, 0 fail; 738 assertions across 11 files |
| Package build | Pass |
| Fresh Callcaster original/new comparison | 2,420 files; all 13 rule counts match; 1,467 counted violations; both gates pass |
| Exact-lock Quick Canvass original/new comparison | 1,774 files; all 918 identities across eight rules match; both gates pass |
| Quick environment | Clean isolated clone at `884695ae6a80aea87c9b70cc57dd2fa3902c6dbb`; exact `npm ci --ignore-scripts`; ESLint 9.39.4 |
| Packed candidate | 0.3.0; 61 files; source/fixtures excluded; runtime verifier/writer and artwork included |
| Packed adoption pilot | Pass: installed 0.3.0 applied both aliases; original baseline/checker unchanged; all 918 identities retained |
| Fresh install after migration | `npm ci --ignore-scripts --no-audit --no-fund` passes from updated lockfile |
| Existing npm entry point after fresh install | `npm run --silent check:lint-ratchet` passes: 1,774 files, 918 identities, Git-parent guard active |
| Root typecheck/build | Existing `validation` dependency installation cannot resolve `zod` |
| Root tests | Existing `datetime` dependency installation cannot resolve `@internationalized/date` |

Review corrections: verified adoption rejects runner overrides; configuration/lock bytes and conservative project membership are bound to the proof; npm's actual executable and a declared dependency are checked. The source-membership check excludes Git/dependency internals, fixed cache output, and owned transaction files.

Reference comparison uses a supplied scan; external reports remain caller-trusted input. The fixed-profile runner is available through `--exec-eslint`. File commits are individually atomic with ownership-aware rollback on normal errors, not a power-loss transaction. A passing comparison does not replace a full consuming-project CI run.


## Release candidate

The locally packed candidate is `chester-hill-solutions-ratchet-strap-0.3.0.tgz`, SHA256 `0420cdc0878ebb2db94063623d6a2acba18b52c78e782f58352ee049a6fd6046`. Runtime verification used Node v25.9.0. The 0.3.0 artifact contains 61 files, including artwork and built runtime/declarations; source and original-checker fixtures are excluded.

Quick Canvass's exact-lock source checkout first matched the original checker with no project mutations. The packed pilot then installed RatchetStrap as a development dependency, applied only supported script aliases plus the new baseline, and preserved the original checker/baseline bytes. A clean lockfile install re-created the npm executable link, and the unchanged `check:lint-ratchet` entry point passed through the new adapter. Only the owned temporary checkout was modified; actual consumer repositories remain untouched by this work. Full consuming-project CI was not run.

The unchanged legacy traversal made the initial Quick comparison take about 113 seconds; installed verification/application took about 105 seconds and the migrated cached gate about 36 seconds. No performance improvement is claimed.

## Retrospective

Original-checker execution and actual npm installation exposed adoption issues that count-only fixtures missed. Fixed invocation, source membership, and executable resolution each now have focused regressions. The same packed artifact then passed a fresh-install consuming-project run. Existing tools remain useful reference points; this milestone keeps RatchetStrap's custom scope centered on preserving existing project contracts and making their adoption reviewable.
