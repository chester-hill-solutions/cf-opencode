# RatchetStrap consolidation

> Historical design and validation record recovered with this package. Consumer scans and packed-artifact claims below refer to their recorded snapshots; they do not establish a rollout of the current recovery candidate.

This records the completed 0.2.0 checkpoint. The [verified adoption milestone](verified-adoption.md) extends it in 0.3.0 with executable parity and explicit script application.

## Mission

Ship one lint-ratchet product with strict identity baselines, preserved legacy count contracts, discoverable profiles, and reviewable adoption. Callcaster and Quick Canvass supply existing behavior; consumers retain their own rules, scopes, and budgets.

## Key results

1. Original Callcaster and Quick Canvass checker fixtures agree with their compatibility profiles on unchanged, regression, suppression, and improvement cases.
2. A new project uses identities by default: substitutions across files or diagnostic messages fail, repaired identities require explicit tightening, and zero rules stay tracked. Same-file, same-message substitutions remain indistinguishable and are documented.
3. Detection and migration preview identify supported legacy contracts without executing project code or altering scripts. Baseline creation is explicit and never overwrites.
4. The packed Node CLI works without source files or a neighboring CHS checkout; package source/test typing, tests, and build pass.

## Assumptions

- Changes belong to `packages/ratchet-strap`; existing user changes stay intact.
- Implement and verify here. Consumer rollout and registry publication are separate release operations.
- Retain schema-1 counts and existing public functions. Introduce schema-2 identity baselines without implicit conversion.
- No new lint engine, arbitrary command runner, remote registry, or consumer test framework.

## Locked design decisions

| Decision | Choice |
| --- | --- |
| New-project default | `eslint@1` profile, `eslint-identities@1` adapter |
| Count compatibility | Existing `eslint-json@1` and `callcaster-lint@1` |
| Quick Canvass compatibility | `quick-canvass@1` profile; original diagnostic identities and cycle traversal |
| Identity shape | `{schemaVersion:2, mode:"identities", adapter, identities:{ruleId:[identity]}}` |
| Check versus tighten | Check fails on new/stale identities; tighten may remove stale entries only, with no new debt/errors |
| Baseline growth | Explicit predecessor comparison rejects newly allowed debt; the Quick Canvass CLI also reads its Git parent automatically |
| Policy versus detector | Named shared ESLint configurations remain separate from report adapters and local budgets |
| Migration | JSON preview plus optional new-baseline creation; script changes are proposals until parity is reviewed |

## Orchestration pattern

Supervisor with parallel implementations, then sequential integration and independent review. The orchestrator and agent-supervisor skills guide task boundaries.

```mermaid
flowchart LR
  Contract --> Identity
  Contract --> Compatibility
  Contract --> Migration
  Identity --> Integration
  Compatibility --> Integration
  Migration --> Integration
  Integration --> Review
  Review --> Verification
```

## Team and subtasks

| ID | Role | Model tier | Goal | Success criterion |
| --- | --- | --- | --- | --- |
| A | Implementer / generalPurpose | large | W2 identity engine | Set comparison and tightening tests pass |
| B | Implementer / generalPurpose | large | W3 Quick Canvass adapter | Original-checker parity tests pass |
| C | Implementer / generalPurpose | mid | W4 migration discovery | Preview/import tests preserve every allowance |
| Root | Integrator / generalPurpose | large | W1, W5–W8 | One documented and verified product |

## Subtask briefs

- **A:** Own `identity.ts` and `identity.test.ts`; read the frozen `identity-types.ts` contract and shared `eslint-report.ts`. Implement parsing, observation, evaluation, importing, tightening. No CLI or count-engine edits. Depends on W1.
- **B:** Own `quick-canvass.ts`, cycle implementation, parity tests, and Quick Canvass fixtures. Read the same contracts. Preserve the existing traversal and identity rules; no writes in the consumer repo. Depends on W1; integrates A's observer.
- **C:** Own migration/discovery module and its tests. Return structured suggestions and imported baselines; never execute legacy code or edit package scripts. Depends on W1; uses A's importer.
- **Root:** Own contracts/parser, profiles, common dispatch, CLI integration, docs, release metadata, and final evidence. Review each handoff before accepting it.

## Individually enumerated backlog

| ID | Work | Agent role | Model tier | Depends on | Done when |
| --- | --- | --- | --- | --- | --- |
| W1 | Freeze contracts | Root / generalPurpose | large | — | Types, shared parser, and plan exist |
| W2 | Implement identity budgets | A / generalPurpose | large | W1 | No replacement/new debt or stale-entry bypass |
| W3 | Preserve Quick Canvass | B / generalPurpose | large | W1 | Counts, identities, cycles, gate outcomes match fixtures |
| W4 | Preview migration | C / generalPurpose | mid | W1 | Both legacy formats import losslessly; unknown checkers remain unrecognized |
| W5 | Unify CLI profiles | Root / generalPurpose | large | W2–W4 | Init/check/tighten/inspect/detect/migrate use one workflow |
| W6 | Document rule lifecycle | Root / generalPurpose | mid | W5 | README examples match actual default and legacy behavior |
| W7 | Review integrated behavior | Reviewer / generalPurpose | large | W5 | Actionable findings fixed; compatibility limits recorded |
| W8 | Verify artifact | Root / shell | mid | W6–W7 | Package checks, packed Node smoke, parity evidence pass |

W2–W4 are parallel-safe with exclusive file ownership. Two failed attempts trigger a narrower brief and parent review before another attempt; do not add agents indefinitely.

## Scope

In: W1–W8. The minimal surface is built-in lint profiles, count/identity comparison, explicit predecessor validation, baseline import, and migration previews.

Out: automatic package-script replacement, publication, changes to consumer repos, metrics/coverage adapters, effects/async extraction, automatic detector upgrades, or fingerprint-based configuration enforcement. These require their own contracts and adoption evidence.

## Risks and backout

| Risk | Response |
| --- | --- |
| Identity format loses legacy details | Preserve the original format and compare against an unmodified checker |
| Counts silently weaken a migrated identity gate | Never convert identities to counts; import preserves comparison mode |
| Smarter lint changes identity text | Pin detector versions; upgrades require reviewed comparison |
| Cycle traversal is slow | Preserve compatibility first; do not claim a bounded or improved algorithm |
| Other repo work breaks root checks | Record failures separately and avoid unrelated fixes |

Backout: existing checkers and baselines remain in place; migration creates a separate file. Schema-1 APIs remain available.

## Rubric and acceptance

| Criterion | Evidence |
| --- | --- |
| No weakened existing contract | Original-checker parity fixtures |
| Strict default | Same-count replacement, stale-entry, zero-rule, and suppression cases |
| Reviewable migration | Read-only detection and preview; exclusive baseline creation |
| Standalone artifact | Packed CLI smoke using Node and installed package files |

## Verification

`bun run --cwd packages/ratchet-strap typecheck`, `test`, and `build`; original-checker compatibility suites; `npm pack` and extracted-artifact Node smoke; root typecheck/test/build when installation permits. Existing dependency problems are reported separately.

## Deliverable

One consolidated package change with public types, profiles, CLI, documentation, fixtures, tests, and evidence. No release or external rollout is claimed.

## Execution gate

Default mode: execute W1, fan out W2–W4, then integrate W5–W8. No additional approval is required for these reversible local changes.

## Progress

- W1: complete.
- W2–W4: complete; independent identity, compatibility, and migration tests passed.
- W5: complete; unified CLI and safe rule-addition workflows pass integration tests.
- W6: complete; README includes actual modes, lifecycle, authoring, migration previews, and limitations.
- W7: two review findings addressed: leading-dash script paths are normalized, and identity-collision limits are explicitly tested/documented.
- W8: complete; results below.

## Verification results

Verified on 2026-11-03:

| Check | Result |
| --- | --- |
| Package source and test typechecking | Pass |
| Package Bun tests | 123 pass, 0 fail, 356 assertions across eight files |
| Package TypeScript build | Pass |
| Packed 0.2.0 artifact | 41 files; source and original-checker fixtures excluded; artwork included |
| Isolated Node CLI / public package API | Pass from extracted package installed in a temporary consumer layout |
| Report-only operation without ESLint installed | Pass |
| Optional ESLint runner | Pass against installed ESLint 9.39.5: init, check, stale repair, preview/write tightening, rule addition, replacement rejection |
| Actual Callcaster project detection / preview | Recognized; 13 unchanged budgets totaling 1,514 permitted warnings |
| Actual Quick Canvass detection / preview | Recognized; all 918 identities across eight rules retained |
| Whole-tree Quick Canvass parity | Not established: its local ESLint executable is missing |
| Root typecheck/build | Stops on existing missing `zod` resolution in `packages/validation` |
| Root tests | Stops on existing missing `@internationalized/date` resolution through `packages/datetime` |
| Whitespace checks | Pass |

The packed smoke run initially hit an unsupported Python tar-extraction option in the verification harness. Replacing that harness step with the system tar command allowed the unchanged packed artifact to complete its Node/ESLint checks. No package change was needed for that harness failure.

The release remains unpublished. Existing consumer checkers, baselines, scripts, and CI entry points were not modified.

## Retrospective

Frozen contracts and exclusive file ownership let identity, compatibility, and migration work proceed independently. The integration review found a real argument-parsing edge case and an overbroad identity claim; both now have focused regression/boundary coverage. Future identity improvements should define collision and code-movement behavior before selecting an encoding. No additional agent round was needed after those corrections.
