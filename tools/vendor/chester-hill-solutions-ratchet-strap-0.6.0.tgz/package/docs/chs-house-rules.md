# CHS House Rules

The [golden set](../README.md#golden-rules) has two layers:

- **Defaults** (`GOLDEN_RULES`) — twelve rules every RatchetStrap consumer
  follows, whatever its language, framework or product.
- **Profiles** (`GOLDEN_PROFILES`) — opt-in rule sets for a stack or concern.

**CHS House Rules are the profiles Chester Hill Solutions enables in most of its
repositories.** They are not the open-source default: a consumer that does not
use React, React Router, a client bundle or the Vault should not inherit them.
`CHS_PROFILES` names the composition; this document records the thresholds and
the gate that enforces each rule.

## Enabled profiles

```ts
import { CHS_PROFILES, GOLDEN_PROFILES } from "@chester-hill-solutions/ratchet-strap";
```

`CHS_PROFILES` is `typescript`, `react`, `react-router`, `web`, `ui`, `quality`,
`telemetry`, `release`, `vault`.

## House rules and enforcement

| Profile | Id | Rule | CHS gate |
| --- | --- | --- | --- |
| `typescript` | `ts.strict` | `strict`, `noUncheckedIndexedAccess`, `noImplicitOverride`, `noImplicitReturns`. | `check:strict-types` |
| `typescript` | `ts.no-escape` | No `@ts-ignore`/`@ts-nocheck`; `@ts-expect-error` carries a description; `as any`/`as unknown as` ratcheted. | ESLint `ban-ts-comment` + strict-type baseline |
| `react` | `react.state-machine` | Lifecycle changes use a named event reducer or transition table; no literal state setters. | `gold/lifecycle-state`, `check:state-machines` |
| `react` | `react.effects` | Every effect documents purpose, deps, side effects and why-not-loader, or is `CANDIDATE-REMOVE`. | `gold/effect-contract` |
| `react-router` | `router.loaders` | Loads and mutations go through loaders/actions/fetchers. | effect contract + route tests |
| `react-router` | `router.authorization` | Membership and role checks use typed middleware or the handler factory. | route/tenancy tests |
| `react-router` | `router.request-integrity` | A body is consumed once; signed webhooks verify before processing. | `gold/body-once` + route tests |
| `web` | `web.client-bundle` | No server module, DB import or credential marker in client assets. | `check:client-bundle` |
| `ui` | `ui.design-system` | Use `@chester-hill-solutions/ui-kit` and its tokens/themes; no ad-hoc styles where the kit has a component. | UI-kit registry + design review |
| `quality` | `quality.duplication` | Clone and duplicated-line counts stay at or below the reviewed ceilings. | `check:dry` (jscpd) |
| `quality` | `quality.file-size` | No file grows past its reviewed line ceiling. | `check:file-size` |
| `quality` | `quality.async-sequencing` | Sequential and repeated awaits are explicit and reviewed. | `gold/async-sequencing` |
| `telemetry` | `telemetry.boundaries` | Every production effect boundary is observed or recorded. | `check:telemetry` |
| `release` | `release.versioned` | A published change carries a version bump and changelog line. | `check-version-bumps` |
| `release` | `release.adr` | A format change ships an ADR, dual-read window and rollback. | `docs/adr/` review |
| `vault` | `G1`–`G13` | Credential and ciphertext invariants. | reliability contracts, Vault profile, golden gate |

## Thresholds

The shared quality policy is `chs-quality@1`: complexity 20, depth 4, parameters
5, function size 200 (excluding blanks and comments), with warnings for console
calls, return-await and non-null assertions.

Repositories that adopt the stricter gold policy use complexity 10, depth 3,
parameters 4 and function size 80, plus `eqeqeq` and
`@typescript-eslint/no-explicit-any`. Aboiteau is the current reference for that
profile. Thresholds are consumer configuration, not part of this registry.

## Vault credential rules

The `vault` profile keeps the original G1–G13 registry, including its pending
tickets and its two existing enforcements (G9's baseline contract and G13's
review anchor). See the
[Vault credential platform plan](../../../docs/VAULT-CREDENTIAL-PLATFORM.md)
for the ticket context.

| Id | Invariant | State |
| --- | --- | --- |
| G1 | Nothing but versioned ciphertext reaches a `VaultStore`. | pending VLT-01 |
| G2 | No secret value appears in a response, log, span or error. | pending RS-03 |
| G3 | Workspace identity is bound, never passed by the caller. | pending RS-03 |
| G4 | User-facing surfaces are write-only. | pending RS-03 |
| G5 | Every credential read is audited, or refused. | pending AUD-07 |
| G6 | A credential is never promoted unverified. | pending CAT-09 |
| G7 | Verification never mutates the provider. | pending RS-03 |
| G8 | Ciphertext is bound to its identity. | pending CRY-09 |
| G9 | A baseline may only shrink. | contract `ratchet.writeBaseline.invariant` |
| G10 | `vault` has no Node builtins or auth dependency. | pending RS-03 |
| G11 | Published changes are versioned and documented. | pending RS-06 |
| G12 | Erasure is cryptographic. | pending CRY-08 |
| G13 | Format changes require an ADR, dual-read and rollback. | review `format-change-requires-an-adr` |

## Adopting the house rules

1. Start with `GOLDEN_RULES`; the defaults are not optional.
2. Enable only the profiles that match the repository:
   `CHS_PROFILES` for a CHS app, or a subset for a package.
3. Map each enabled rule to a detector in the repository's gate. A profile rule
   with `kind: "consumer"` names the detector generically; the consumer supplies
   the implementation.
4. Keep the gate in the same aggregate command as CI, with a fault and control
   fixture for every new detector.
5. Record CHS-specific thresholds and exemptions in the repository, not in this
   package.
