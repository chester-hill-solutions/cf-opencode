# Portfolio adoption validation

> Historical design and validation record recovered with this package. Consumer scans and packed-artifact claims below refer to their recorded snapshots; they do not establish a rollout of the current recovery candidate.

Date: 2026-11-03. Implementation follows [the portfolio plan](portfolio-adoption.md) and [adopter audit](adoption-candidates.md).

## Delivered package changes

- RatchetStrap 0.4.0 adds Sparkfunds Helcim's verified migration profile and Stow's explicit TS lint importer/profile.
- Restored the existing upstream ESLint-config package and added its pure `/ratchet-rules` export. Shared thresholds have one source. RatchetStrap bundles the record during build; the published CLI and declarations need no ESLint-config runtime/type dependency.
- Preserved the upstream CHS generic count contract through a frozen-reference comparison. No additional generic scanner was introduced.
- Helcim's flat `{}` imports seven zero budgets. Valid reports retain its original message-only accounting, including tracked errors and ignored suppressions. Its preceding lint gate stays mandatory; apply additionally checks lint success. Invalid/empty scans fail closed.
- Stow retains ten rules, ESLint suppression metadata, strict stale counts, downward tightening, required Git-base lookup and nested execution. It explicitly requires the nested ESLint executable and cannot fall back to an ancestor install. New malformed history fails closed; legacy first-adoption behavior remains explicit.
- NES receives a supplementary strict identity gate with a fresh app-only report, its original 500-warning ceiling and all existing guards retained.

Stow has no automatic `verify`/`migrate --apply` support. Its manual adoption patch is validated separately. Go, coverage, duplication, file-size, effects and type-escape detectors were not migrated.

## Package verification

| Check | Result |
| --- | --- |
| RatchetStrap source and test typecheck | Pass |
| RatchetStrap tests | 255 pass, 0 fail; 1,075 assertions across 14 files |
| RatchetStrap build | Pass |
| ESLint-config build and typecheck | Pass |
| ESLint-config tests | 4 pass, 0 fail; 9 assertions |
| Extracted Node CLI | Pass: 0.4.0, six profiles, seven shared rules |
| Artifact contents | 71 files; no source/fixtures/node_modules, no runtime dependencies |
| Shared policy declarations | No external ESLint-config type dependency |
| Independent review | One Stow runner gap reproduced and corrected; nested-only regression passes; no remaining actionable findings |

The independent review caught generic Node resolution accepting an ancestor ESLint when Stow's nested executable was missing. The corrected runner uses exactly `packages/stow-s3/node_modules/eslint/bin/eslint.js`; both the original failure and new fail-closed result are covered.

## Consumer pilots

Pilots use isolated feature-branch checkouts. Real consumer checkouts and remote repositories were not changed.

| Project/source | Actual scan and preserved contract | Validation |
| --- | --- | --- |
| Sparkfunds Helcim `352e96e8e6d6ff8a21ff4cb0d920dcd7f18e1eb4` | Exact npm lock, ESLint 9.39.5; 12 files; all seven counts zero | Final packed install, same-report verification, guarded apply, npm lint and adopted ratchet pass; all 68 installed dist files match final tarball bytes |
| NES CRM `74d4c6cd1010112b20b4295fba9b2d1c2788e866` | Exact filtered Bun lock, ESLint 9.39.4; 1,240 files; 5 visible warnings plus 329 suppressed tracked diagnostics; 334 identities across six warning rules | Final packed wrapper, frozen reinstall and Bun executable pass; all 71 installed published files match tarball bytes; planted regression/repair cases pass |
| Stow `0de768c8e8de806456f9e1a0bdaa286a68ac7e4a` | Sparse clone includes all TS lint inputs; exact existing tool versions via thin links; ESLint 10.12.0; 142 files; ten zero counts | Original gate, same-report adapter, final packed nested npm script and tightening pass; invalid history fails; planted warning fails both original/new gates and restoration passes; all 71 installed published files match tarball bytes |

NES planted cases verify that a new warning accepted below the old ceiling fails the identity gate, tightening refuses new debt, hard errors and the 500-warning ceiling still stop execution, and repair requires explicit tightening. A repaired baseline reduced 334 to 333 before source and baseline were restored and the clean gate passed again.

Installed-byte checks caught Bun retaining a preliminary local tarball when its filename/version was reused. A distinct final tarball filename forced the intended package selection; the final frozen install and every installed published file were then verified. Release consumers should install the immutable published version rather than reuse local candidate filenames.

Stow contract fixtures also cover growth, stale improvements, suppressions, hard errors, expanded budgets, missing/unresolvable Git refs, migrated history, malformed legacy history and unknown/missing metrics.

All three proposals include scoped GitHub Packages configuration with environment-variable token placeholders and package-read authentication in the CI jobs that install the affected dependencies. NES includes all three workflows installing its Bun workspace; Stow scopes `.npmrc` to the nested SDK and preserves existing publishing permissions. YAML syntax, local configuration resolution, local-artifact installs/gates and patch application checks pass. No credentials were embedded. Hosted authorization remains unverified until publication and package Actions access grants.

## Existing failures outside this change

- Root typecheck/build reaches the existing validation installation and cannot resolve `zod`.
- Root tests fail while loading existing campaign-work suites because datetime's installed runtime cannot resolve `@internationalized/date`.
- Helcim's original and adopted `ci:local` both run seven passing Node tests and then fail because committed `scripts/coverage/merge-and-check.mjs` is missing.
- NES's unchanged effect appendix fails because `contact-table-cell.tsx` is at line 274 while the committed inventory says 276. Original lint and CRM typecheck pass. The guard and inventory were not edited.
- Stow's full Go/coverage/DRY/standards pipeline was not run for this TS lint pilot.

These results do not establish full-project CI success. The source, detector and baseline contracts remain available for review/backout.

## Artifacts and rollout boundary

Local delivery directory: `.artifacts/ratchet-strap-0.4.0/` at the CHS repository root. It contains packed candidates, source-linked evidence and consumer patches. Generated delivery files are ignored by Git.

| Artifact | SHA256 |
| --- | --- |
| `chester-hill-solutions-ratchet-strap-0.4.0.tgz` | `fddb2f96d9e4fe04153c360141bff39692902d21d82f6477f3338466964f6abf` |
| `chester-hill-solutions-eslint-config-0.2.0.tgz` | `ff718df9cd12a0af5cd94861faa4b3c1c5798199969aec02da679cc3d172d64f` |

The candidates use the publishing script's package shape: compiled files and metadata with development dependencies/scripts removed. They have not been published.

Consumer patches are explicitly separated:

- Release-dependent patches pin 0.4.0 but do not fabricate registry integrity or claim an installable registry lock. Publish the package, generate the actual consumer lock, and review that diff before merging them.
- Local-artifact pilot patches/archives record the installed tarball and lock actually used during validation. Their temporary/vendor paths are pilot infrastructure, not production registry coordinates.

After publishing, grant the three consumer repositories access in RatchetStrap's Package settings → Manage Actions access. The supplied workflow tokens cannot establish access to an unpublished package.

Original checkers/baselines remain intact. Real-project rollout, publication, remote pushes and merges are not claimed by this work.
