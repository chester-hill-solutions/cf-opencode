# CHS adoption candidates

> Historical design and validation record recovered with this package. Consumer scans and packed-artifact claims below refer to their recorded snapshots; they do not establish a rollout of the current recovery candidate.

Audit date: 2026-11-03. Screened 68 accessible CHS organization repositories through repository discovery and indexed code searches, then inspected local manifests and selected checker implementations. This is a portfolio screen with deeper reads of the strongest candidates, not a complete code audit of all 68 repositories.

No consumer files were changed, dependencies installed, or candidate checks executed. CI references establish workflow wiring, not passing hosted runs. Local branches can differ from default branches; fetched default-branch evidence resolves the important CHS and Riding/address differences below.

At this audit's 0.3 checkpoint, recognized verified migrations covered Callcaster and Quick Canvass lint. The subsequent [portfolio validation record](portfolio-validation.md) documents the implemented 0.4 adapters and pilots. Candidate requirements below retain the original audit findings.

## Recommended adoption order

| Candidate | Existing contract | Recommended entry | Required work |
| --- | --- | --- | --- |
| Sparkfunds Helcim | Seven-rule ESLint count gate; flat empty baseline means zero debt | Next small compatibility profile | Import the seven zero budgets without measuring new debt; recognize its checker and invocation; prove parity |
| Stow S3 | Shared engine for lint, type escapes, file size, duplication, Go quality and coverage | Next substantial consolidation target; start with TS lint | Strict stale-count handling, history refs, nested package execution, verified lint profile; broader detector adapters later |
| NES Dashboard CRM | ESLint with a fixed 500-warning ceiling and exact effect inventory | First new generic identity-baseline adopter | Preserve app-only scope, hard errors, warning ceiling and inventory gate; add a new identity gate alongside them |
| Sparkfunds / Contribox | Per-file type-cast counts and handler identities | First custom TypeScript detector pilot | Text-baseline importers and structured observations; preserve stale failures and strict directories |
| Riding and Address | Per-file coverage floors and zero runtime-cycle baseline | Coverage capability pilot | Percentage floors/tolerances, independent root/portal scope, SCC adapter and explicit update policy |
| Crab Browser | Swift source scanner with exact path/line allowlist | Later non-JavaScript pilot | Non-ESLint observation/import adapter; preserve scanner/self-test; decide how to provision the Node CLI |

These are different adoption paths. The ordering balances a small migration against proving that shared management can preserve more demanding contracts.

## Existing CHS infrastructure to reconcile first

Upstream CHS already has [`@chester-hill-solutions/eslint-config`](https://github.com/chester-hill-solutions/chester-hill-solutions/blob/934529a9c0568ec011aee659b09f965b62b49d3b/packages/eslint-config/README.md). Its [`ratchetRules`](https://github.com/chester-hill-solutions/chester-hill-solutions/blob/934529a9c0568ec011aee659b09f965b62b49d3b/packages/eslint-config/src/index.ts#L48) duplicates RatchetStrap's current seven-rule preset. This package is absent from the local checkout inspected during this work.

Upstream also has a tested [`scripts/lib/ratchet.mjs`](https://github.com/chester-hill-solutions/chester-hill-solutions/blob/934529a9c0568ec011aee659b09f965b62b49d3b/scripts/lib/ratchet.mjs#L185), including count comparison, unmeasured-rule protection, fail-closed source reads and downward-only updates. Its executable behavior permits unrecorded improvements; an older header comment suggesting otherwise is stale. Scriptkit's separate baseline helper compares exact snapshots and should not be mistaken for downward-only debt management.

Recommended ownership: ESLint-config owns reusable lint configuration; RatchetStrap owns baseline comparison, compatibility profiles and migration. Reconcile the existing helper's tested contracts before extracting another generic scanner. The CHS monorepo is itself a useful consolidation and dogfood candidate.

## Candidate evidence and preservation requirements

### Sparkfunds Helcim

This is separate from Sparkfunds / Contribox. Its [checker](https://github.com/chester-hill-solutions/sparkfunds-helcim/blob/352e96e8e6d6ff8a21ff4cb0d920dcd7f18e1eb4/scripts/check-lint-ratchet.mjs#L10) tracks seven fixed rules and runs `npx eslint -f json .`. Its [baseline](https://github.com/chester-hill-solutions/sparkfunds-helcim/blob/352e96e8e6d6ff8a21ff4cb0d920dcd7f18e1eb4/scripts/baselines/lint-ratchet.json) is literally `{}`: absent rule keys mean zero. Current importers do not accept this contract. Initialization from measured debt would silently weaken it.

The checker counts tracked messages without filtering severity and does not inspect suppression metadata or comments. Its [quality policy](https://github.com/chester-hill-solutions/sparkfunds-helcim/blob/352e96e8e6d6ff8a21ff4cb0d920dcd7f18e1eb4/docs/code-quality-guardrails.md#L7) calls for suppression protection. Adding RatchetStrap's stronger behavior would be deliberate hardening, distinct from exact legacy compatibility. Preserve its app-owned scopes, hard errors and plugin setup. [CI](https://github.com/chester-hill-solutions/sparkfunds-helcim/blob/352e96e8e6d6ff8a21ff4cb0d920dcd7f18e1eb4/.github/workflows/ci.yml#L12) already invokes the existing quality chain.

### Stow S3

Stow already centralizes comparison in [`scripts/ratchet.mjs`](https://github.com/chester-hill-solutions/stow-s3/blob/main/scripts/ratchet.mjs#L24). Counts fail on growth and stale improvements; identity sets fail on additions and stale entries. RatchetStrap's legacy count mode currently allows improvements before tightening, so its semantics differ.

The [history helper](https://github.com/chester-hill-solutions/stow-s3/blob/main/scripts/baseline-history.mjs#L3) requires a resolvable `STOW_BASELINE_REF` or `HEAD^`; [CI](https://github.com/chester-hill-solutions/stow-s3/blob/main/.github/workflows/ci.yml#L257) fetches full history and runs `make standards`. Its [lint detector](https://github.com/chester-hill-solutions/stow-s3/blob/main/scripts/check-lint-ratchet.mjs#L8) executes inside `packages/stow-s3`, tracks ten rules and counts ESLint suppression metadata. A `{counts}` shape alone does not make it Callcaster-compatible.

Other gates include AST type-escape identities, file-size observations, fractional duplication metrics, mixed Go counts/identities and coverage floors. File-size identities include actual line counts, so legitimate shrinking files need special handling when comparing baseline history. Preserve existing detectors until their report contracts are supported. Start with verified TS lint orchestration and reuse the existing pure comparison policy where appropriate.

### NES Dashboard CRM

The inspected local [manifest](/Users/ladmin/WebProjects/nes-dashboard/crm/package.json:11) runs `eslint app --max-warnings 500`. Its [ESLint configuration](/Users/ladmin/WebProjects/nes-dashboard/crm/eslint.config.js:44) also contains hard errors. No shrinking lint-debt baseline was found. Its [effect appendix checker](/Users/ladmin/WebProjects/nes-dashboard/crm/scripts/check-use-effect-appendix.sh:13) enforces an exact generated inventory; it is not a debt allowance. [CI](/Users/ladmin/WebProjects/nes-dashboard/.github/workflows/crm-ci.yml:112) runs lint and the appendix check.

A new identity baseline would prevent repaired warnings from being replaced by unrelated warnings under the existing global ceiling. Keep the existing ceiling and guards. Preserve the `app` scan scope by supplying the matching report or adding scoped execution support; the generic CLI's default `.` runner is not the same invocation. This is new adoption, not an existing-profile migration.

### Sparkfunds / Contribox

The default-branch [type-strictness checker](https://github.com/chester-hill-solutions/sparkfunds/blob/main/scripts/check-types-strict/index.mjs#L5) counts `as any` / `as unknown as` per file. It rejects growth and stale improvements, and its update command refuses increases. The text baseline uses count/tab/path records.

The [handler checker](https://github.com/chester-hill-solutions/sparkfunds/blob/main/scripts/handler-registry/index.mjs#L14) tracks path/export identities. Both additions and stale entries fail. Promoted strict directories reject violations even if someone adds them to the baseline. Updates cannot add identities. [CI](https://github.com/chester-hill-solutions/sparkfunds/blob/main/.github/workflows/test.yml#L66) runs `check:packages`, which includes these gates.

This is a strong custom-detector candidate. Keep AST discovery and domain annotations in the project initially; share import, comparison and tightening through explicit adapters. Generic per-rule totals would lose its per-file and per-handler protection.

### Riding and Address

The inspected local branch predates coverage enforcement. Actual default-branch [scripts](https://github.com/chester-hill-solutions/riding-and-address/blob/main/package.json#L45) and [CI](https://github.com/chester-hill-solutions/riding-and-address/blob/main/.github/workflows/ci.yml#L58) actively run root and portal coverage gates.

The [coverage checker](https://github.com/chester-hill-solutions/riding-and-address/blob/main/scripts/check-coverage-ratchet.mjs#L50) uses independent Vitest/V8 scans, per-file statement and branch percentage floors, one percentage-point tolerance and stale-file failures. Inspected metadata contained 94 root and 59 portal files. Updates intentionally permit reviewed reductions; no predecessor-history guard exists. Newly appearing files get floors only during an update. Preserve these choices or change them explicitly.

Its [import-cycle checker](https://github.com/chester-hill-solutions/riding-and-address/blob/main/scripts/check-import-cycles.mjs#L40) counts runtime strongly connected components, excluding type-only edges. It is not Quick Canvass's cycle-path detector. Existing lint has a zero-warning policy. Coverage floors and graph observations need new adapters; nonzero lint budgets would weaken the current lint contract.

### Crab Browser

The [no-ambush scanner](https://github.com/chester-hill-solutions/crab-browser/blob/51aecea67905b1d0405175926959fb77c76d51f3/scripts/check-no-ambush.sh#L42) lexically inspects selected Swift regions. Its baseline is an exact `path:line` set; both new and stale entries fail. The inspected baseline has comments only.

Keep the detector's scope, its [planted-fixture self-test](https://github.com/chester-hill-solutions/crab-browser/blob/51aecea67905b1d0405175926959fb77c76d51f3/scripts/no-ambush-selftest.sh), and its [check.sh integration](https://github.com/chester-hill-solutions/crab-browser/blob/51aecea67905b1d0405175926959fb77c76d51f3/scripts/check.sh#L45). RatchetStrap can eventually share set bookkeeping, but needs a non-ESLint adapter and text importer. This Swift project would also acquire a Node toolchain requirement.

## Later or specialized adopters

| Project | Finding | Suitable path |
| --- | --- | --- |
| Campaign OS | [Source guards](/Users/ladmin/WebProjects/campaign-os/scripts/check-source.mjs:155) explicitly forbid mutable baselines and grandfathering; coverage and language checks use real Git bases | Reusable strict rules or a baseline-free profile; do not migrate to debt budgets |
| OuiPermit | [Conformance ratification](/Users/ladmin/WebProjects/OuiPermit/scripts/lib/ratification.ts:69) binds findings to justification, reviewer, date and digest; verdict guards compare semantic outcomes | Specialized reviewed-exception and verdict adapters; preserve metadata and transitions |
| CivicSignal | [Validation](/Users/ladmin/WebProjects/civicsignal/package.json:12) contains architecture/data invariants, vendor verification and runtime checks; no lint-debt ratchet found in inspected setup | Later new lint adoption or reusable invariant guards |
| Mercury Mail | [Integrity checks](/Users/ladmin/WebProjects/mercury-mail/scripts/verify-chs-packages.mjs:5) validate artifact provenance, inventory and hashes; no root lint-debt ratchet found | Later new lint adoption; keep integrity and generated-schema checks independent |

Other ordinary ESLint projects, including Andrew Richardson and Beynate, may adopt a new lint baseline, but the screen did not establish existing ratchet migrations. Domain evaluation fixtures, performance benchmark baselines, model baselines and generated-file snapshots were not treated as lint-debt ratchets.

## Product implications

1. Reconcile upstream shared ESLint configuration and ratchet comparison code before adding more duplicate policy implementations.
2. Add the small Sparkfunds Helcim compatibility profile and prove original/new behavior from the same locked-install report.
3. Pilot generic identity tracking in NES CRM while retaining its existing lint and inventory gates.
4. Use Stow and Sparkfunds to define explicit count/identity observation adapters, stale policy, history refs and package scopes. Keep detection local until each contract has evidence.
5. Treat coverage floors, graph semantics, baseline-free rules and reviewed exceptions as separate future capabilities. Count ceilings alone cannot preserve them.

These recommendations are an audit result, not an implementation or rollout commitment. Actual consumer adoption still requires the appropriate compatibility work and project-level validation.
