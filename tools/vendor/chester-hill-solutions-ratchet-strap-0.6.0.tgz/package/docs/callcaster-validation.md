# Callcaster compatibility validation

> Historical design and validation record recovered with this package. Consumer scans and packed-artifact claims below refer to their recorded snapshots; they do not establish a rollout of the current recovery candidate.

Validated on **2026-11-03** against a fresh, uncached ESLint JSON scan of the local Callcaster checkout.

This is the initial count-compatibility checkpoint. The [consolidation record](product-plan.md#verification-results) records the later 0.2.0 identity/profile/artifact verification. The [verified adoption milestone](verified-adoption.md#current-verification-evidence) records the 0.3.0 fresh comparisons for both complete projects.

- Callcaster HEAD: `acf620485b2456f3a6cf5d21094310452253211e`. The working tree had local changes; this is a validation of that local source snapshot.
- Checker contract: unmodified `scripts/check-lint-ratchet.mjs` from `91c4409b28321504eb07f169801542a61ed7d4a8` (Git blob `99ccc9163dbc2d71ad0dde01e2d384cf026008d1`).
- Files scanned: **2,420**.
- Tracked rules: **13**, with all observed counts equal in the original checker and `callcaster-lint@1`.
- Original gate exit: **0**. RatchetStrap gate exit: **0**. Unsuppressed ESLint errors: **0**.
- Counted warnings/directives: **1,467**.

| Rule | Existing budget | Original observed | RatchetStrap observed |
| --- | ---: | ---: | ---: |
| `shadcn/no-restyle` | 812 | 796 | 796 |
| `shadcn/no-arbitrary-values` | 170 | 162 | 162 |
| `max-lines-per-function` | 56 | 54 | 54 |
| `shadcn/no-inline-styles` | 43 | 43 | 43 |
| `shadcn/no-raw-colors` | 114 | 102 | 102 |
| `complexity` | 112 | 110 | 110 |
| `@typescript-eslint/no-non-null-assertion` | 117 | 116 | 116 |
| `shadcn/no-unknown-classes` | 21 | 20 | 20 |
| `shadcn/require-static-classes` | 9 | 9 | 9 |
| `max-params` | 6 | 5 | 5 |
| `max-depth` | 21 | 20 | 20 |
| `no-return-await` | 22 | 19 | 19 |
| `no-console` | 11 | 11 | 11 |

## Method

1. Run Callcaster's installed ESLint with `. --format json --no-cache`, saving its full report outside both repositories.
2. Copy the frozen original checker and existing baseline into a temporary harness. Supply the same saved report through a local `npx` shim; source paths still point to the actual Callcaster files.
3. Compare the original gate exit with the compiled RatchetStrap CLI using an imported, versioned copy of the baseline.
4. Run the original checker's baseline writer only inside the temporary harness to obtain its exact observed counts, then compare every tracked count with RatchetStrap.

Callcaster source files, scripts, configuration, and checked-in baseline were not edited. Existing improvements were measured without applying baseline changes. The 49 package tests also cover growth, hard errors, unused/multiple/multiline/wildcard suppression directives, metadata suppression, zero budgets, invalid reports, and baseline writes.

## Package and repository checks

- RatchetStrap: tests, source/test typechecking, TypeScript build, compiled Node CLI smoke checks, and npm packaging dry run passed.
- Root typecheck/build: stopped in `packages/validation` because its existing dependency installation could not resolve `zod`.
- Root tests: stopped in `packages/campaign-work` because `packages/datetime/dist/zoned.js` could not resolve `@internationalized/date`.
- Installing workspace dependencies encountered an existing symlink collision for `@chester-hill-solutions/datetime`. Existing dependency symlinks were preserved.

These results establish lint-count and gate compatibility for the measured tree and fixture cases. Publication, replacing Callcaster's CI scripts, detector upgrades, and migrating other checks are separate changes.
